1. Download and Decompressing

Step 1.1: Download the "health.zip" file which contains all files of the project.

Step 1.2: Decompress it and move the decompressed folder to the environment directory. 
Please NOTE: the tree of project directory should be like the following structure:

--health
  |
  --src/asl
    |
    --agent_name.asl
  --src/java
  --Referenced Libraries
  --bin
  --src
    |
    -- health.mas2j



2. Import the Project

Step 2.1: Open "Eclipse";

Step 2.2: Click "File", then choose "Open Projects from File System";

Step 2.3: Click "Directory", which is at the end of "Import source" bar;

Step 2.4: Select "health" folder in your workspace folder, whose names are "eclipse-workspace" in Mac OS and Windows;

Step 2.5: Tick the square before "health", click "Finish";



3. Run the Project

Step 3.1: After successfully import the project via Eclipse, select the "health" in the Jason Navigator bar, 
we may find that there are 2 errors in the Problems tab, one of which's type is "Build Path Problem", right click it.
Select the "Quick Fix";

Step 3.2: Select "Configure build path...", then click "Finish";

Step 3.3: Select "Libraries" tab, remove MY library, in which case whose name starts with "jason-2.4.jar - ...";

Step 3.4: Switch to "Order and Export" tab, click "JRE System Library [jdk-version]" in Windows and in Mac OS. Click "Apply and Close";

Step 3.5: Now, please feel free to run the project by clicking "Run Jason Application".




